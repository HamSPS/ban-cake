export const environment = {
  production: true,
  title: 'Production Environment Heading',
  apiURL: 'https://api.mangkonedev.tech/ban-cake'
};
