import { Component } from '@angular/core';

@Component({
  selector: 'app-access-deny',
  templateUrl: './access-deny.component.html',
  styleUrls: ['./access-deny.component.scss']
})
export class AccessDenyComponent {

}
