import { Component } from '@angular/core';

@Component({
  selector: 'app-bill-dialog',
  templateUrl: './bill-dialog.component.html'
})
export class BillDialogComponent {

}
