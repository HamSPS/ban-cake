import { Component } from '@angular/core';

@Component({
  selector: 'app-input-quanity',
  templateUrl: './input-quanity.component.html'
})
export class InputQuanityComponent {

}
