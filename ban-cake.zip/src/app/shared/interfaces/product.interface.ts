export interface Product {
  id?: number;
  code?: string;
  name?: string;
  cost?: number;
  price?: number;
  createdAt?: Date;
  updatedAt?: Date;
}
